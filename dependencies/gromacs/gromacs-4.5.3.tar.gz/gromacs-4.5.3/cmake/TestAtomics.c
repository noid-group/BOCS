
#define TMPI_CHECK_ATOMICS
#include "thread_mpi/atomic.h"

int main(void)
{
    return 0;
}


